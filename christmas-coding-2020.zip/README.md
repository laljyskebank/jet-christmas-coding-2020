# Kirby Simple Starter

Dette projekt er et Angular projekt konfigureret til at bruge Kirby Designsystem

---

## Projekt navngivning

For at omdøbe projektet skal følgende gøres

- Åbn projektet og udfør søg og erstat i alle filer "kirby-simple-starter" med det navn som projektet skal hedde. Vigtigt at markere **"Match whole word"** 

---

## Development server

Run `npm start` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
